# TA Instance Segmentation > 2024-04-23 11:39pm
https://universe.roboflow.com/andars/ta-instance-segmentation

Provided by a Roboflow user
License: CC BY 4.0

