# TA Instance Segmentation > 2023-10-25 7:14pm
https://universe.roboflow.com/andars/ta-instance-segmentation

Provided by a Roboflow user
License: CC BY 4.0

